import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math

def get_data(name):
    with open (name + '.csv', 'r') as file:
        reader = csv.reader(file)
        xy = [i for i in reader]

    return xy


filenames = ['data_40', 'data_80', 'data_120', 'data_160']
xy = [0] * 4
name_x = [0] * 4
name_y = [0] * 4
for i in range(4):
    xy[i] = get_data(filenames[i])
    
name_x = xy[0][0]
name_y = xy[0][1]
print(name_x)

xy = [i[1:] for i in xy]

x  = [0] * 4
y  = [0] * 4
coeffs = [0] * 4
y_fit = [0] * 4
for i in range(4):
    x = [float(j[0]) for j in xy[i]]
    y = [float(j[1]) for j in xy[i]]

    u0 = y[0]
    y = [-math.log(j / u0) for j in y]

    coeffs = np.polyfit(x, y, 1)

    print(f'coeffs{i} = ', coeffs)
    
    y_fit = np.polyval(coeffs, x)
    plt.plot(x, y_fit, color='blue', label='Fit 1: y = {:.2f}x + {:.2f}'.format(coeffs[0], coeffs[1]))

f = open("graph_inf.txt", "w")

for i in range(4):
    f.write(f"coeffs{i} = {coeffs[i]}")

plt.ylabel('-ln(U/U0)')
plt.xlabel('t(s)')
plt.title('Scatter Plot from data_40.csv')

plt.xlim(0, 600)
plt.ylim(0, 1)

plt.legend()
plt.savefig('graph')
plt.show()
        
